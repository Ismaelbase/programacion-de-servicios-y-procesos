package bachaou_sevilla_ismael_examen_practico;

import java.util.Random;
import java.util.Scanner;
import java.util.concurrent.Semaphore;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Bachaou_Sevilla_Ismael_Examen_Practico {

    // 0 -> Bocadillos 1 -> Magdalenas 2 -> Tostadas
    static Semaphore[] semaforos_mostrador = {new Semaphore(1), new Semaphore(1), new Semaphore(1)};
    static int[] mostrador = {0, 0, 0};
    static String[] nombres_productos = {"Bocadillo", "Magdalena", "Tostada"};

    static boolean atendidos = false;

    public static class Cocinero extends Thread {

        Cocinero() {

        }

        @Override
        public void run() {

            while (!atendidos) {
                for (int i = 0; i <= 2; i++) {
                    if (i == 0) {
                        try {
                            System.out.println("Cocinero -> Voy a preparar un bocadillo...");
                            sleep(3000);
                            semaforos_mostrador[i].acquire();
                                mostrador[i]++;
                                System.out.println("Cocinero -> Bocata hecho, ahora hay " + mostrador[i] + " bocatas en el mostrador.");
                            semaforos_mostrador[i].release();
                        } catch (InterruptedException ex) {
                            Logger.getLogger(Bachaou_Sevilla_Ismael_Examen_Practico.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    } else if (i == 1) {
                        try {
                            System.out.println("Cocinero -> Voy a preparar una magdalena...");
                            sleep(2000);
                            semaforos_mostrador[i].acquire();
                                mostrador[i]++;
                                System.out.println("Cocinero -> Magdalena hecha, ahora hay " + mostrador[i] + " magdalenas en el mostrador.");
                            semaforos_mostrador[i].release();
                        } catch (InterruptedException ex) {
                            Logger.getLogger(Bachaou_Sevilla_Ismael_Examen_Practico.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    } else if (i == 2) {
                        try {
                            System.out.println("Cocinero -> Voy a preparar una tostada...");
                            sleep(4000);
                            semaforos_mostrador[i].acquire();
                                mostrador[i]++;
                                System.out.println("Cocinero -> Tostada hecha, ahora hay " + mostrador[i] + " tostadas en el mostrador.");
                            semaforos_mostrador[i].release();
                        } catch (InterruptedException ex) {
                            Logger.getLogger(Bachaou_Sevilla_Ismael_Examen_Practico.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }
                }
            }

        }
    }

    public static class Cliente extends Thread {

        Random r = new Random();
        int eleccion = r.nextInt(3);
        boolean servido = false;
        
        static int contador = 0;
        int id = 0;

        Cliente() {
            this.contador++;
            this.id = this.contador;
        }

        @Override
        public void run() {

            try {
                System.out.println("Cliente "+id+" -> Voy a elegir que quiero...");
                sleep(2000);
                System.out.println("Cliente "+id+" -> Ya se, quiero " + nombres_productos[eleccion]);
                while (!servido) {
                    if (mostrador[eleccion] > 0) {
                        semaforos_mostrador[eleccion].acquire();
                            System.out.println("Cliente "+id+" -> Hay "+mostrador[eleccion]+" "+nombres_productos[eleccion]+" en el mostrador, comprare uno.");
                            mostrador[eleccion]--;
                        semaforos_mostrador[eleccion].release();
                        System.out.println("Cliente "+id+" -> Adios.");
                        servido = true;
                    } else {
                        System.out.println("Cliente "+id+" -> Ahora mismo en el mostrador no hay " + nombres_productos[eleccion] + " esperare un poco...");
                        sleep(5000);
                    }
                }

            } catch (InterruptedException ex) {
                Logger.getLogger(Bachaou_Sevilla_Ismael_Examen_Practico.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
    }

    public static void main(String[] args) throws InterruptedException {
        Scanner teclado = new Scanner(System.in);
        
        int cantidad_clientes = 0;
        Cocinero c = new Cocinero();
        
        
        
        System.out.println("Cuantos clientes quieres que vengan?");
        cantidad_clientes = teclado.nextInt();
        
        Cliente[] clientes = new Cliente[cantidad_clientes];
        c.start();
        
        for (int i = 0; i < cantidad_clientes; i++) {
            clientes[i] = new Cliente();
            clientes[i].start();
            clientes[i].join(1000);
        }
        
        int total_acabados = 0;
        
        
        while(!atendidos){
            total_acabados = 0;
            for (int i = 0; i < cantidad_clientes; i++) {
                if(!clientes[i].isAlive())
                    total_acabados++;
            }
            
            if(total_acabados == cantidad_clientes){
                atendidos = true;
                System.out.println("Restaurante -> Listo, todos los clientes atendidos.");
            }
        }
        
    }

}
