package vocales;
import java.util.concurrent.Semaphore;

public class Vocales_Monitor {
    
    private static int cuenta_total = 0;
    private static String txt = "";
    private static Object monitor = new Object();
    
    static void Contar_a(){
        String[] partido = txt.split("");
        
        synchronized (monitor){
            for(int i = 0 ; i < partido.length;i++){
                if(partido[i].equalsIgnoreCase("a")){
                    cuenta_total++;
                    System.out.println("Cuenta A: "+cuenta_total);
                }
            }
        }
    }
    
    static void Contar_e(){
        String[] partido = txt.split("");
        
        synchronized (monitor){
            for(int i = 0 ; i < partido.length;i++){
                if(partido[i].equalsIgnoreCase("e")){
                    cuenta_total++;
                    System.out.println("Cuenta E: "+cuenta_total);
                }
            }
        }
    }
    
    static void Contar_i(){
        String[] partido = txt.split("");
        
        synchronized (monitor){
            for(int i = 0 ; i < partido.length;i++){
                if(partido[i].equalsIgnoreCase("i")){
                    cuenta_total++;
                    System.out.println("Cuenta I: "+cuenta_total);
                }
            }
        }
    }
    
    static void Contar_o(){
        String[] partido = txt.split("");
        
        synchronized (monitor){
            for(int i = 0 ; i < partido.length;i++){
                if(partido[i].equalsIgnoreCase("o")){
                    cuenta_total++;
                    System.out.println("Cuenta O: "+cuenta_total);
                }
            }
        }
    }
    
    static void Contar_u(){
        String[] partido = txt.split("");
        
        synchronized (monitor){
            for(int i = 0 ; i < partido.length;i++){
                if(partido[i].equalsIgnoreCase("u")){
                    cuenta_total++;
                    System.out.println("Cuenta U: "+cuenta_total);
                }
            }
        }
    }
    
    public static void main(String[] args) {
        
        txt = "Vamos a comprobar las vocales que tiene este texto.";
        
        Contar_a();
        Contar_e();
        Contar_i();
        Contar_o();
        Contar_u();
        
        
    }
}
