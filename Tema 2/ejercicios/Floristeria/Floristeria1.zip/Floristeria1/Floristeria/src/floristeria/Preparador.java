package floristeria;

import java.util.concurrent.Semaphore;

public class Preparador extends Thread{
    String nombre;
    Semaphore sem;
    String flor;
    
    public Preparador(String nom, String flor,Semaphore s){
        this.nombre = nom;
        this.sem = s;
        this.flor = flor;
    }
    
    @Override
    public void run(){
        
        System.out.println("Soy el preparador "+this.nombre+" y voy a preparar la flor: ."+this.flor);
        Ramo r = new Ramo(sem);
        r.añadirFlor(flor);
    }
}
