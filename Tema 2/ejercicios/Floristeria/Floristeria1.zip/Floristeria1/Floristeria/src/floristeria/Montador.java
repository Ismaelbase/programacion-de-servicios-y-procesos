package floristeria;

public class Montador extends Thread{
    public static Integer cantidad_ramos = 0;
    String nombre = "";
    
    Montador(String nom, int ramos ){
        
        this.cantidad_ramos = ramos;
        this.nombre = nom;
    
    }
    
    @Override
    public void run(){
        Ramo r = new Ramo();
        if(r.verClavel() != 0 && r.verLirio() != 0 && r.verRosa() != 0){
            
            System.out.println("Soy el montador "+this.nombre+", hay al menos una flor de cada tipo, voy a montar un ramo!");
            
            
        }else{
            throw new RuntimeException("Faltan flores ! ");
        }
    }
    
    
    
//    public void run(){
//        System.out.println("Soy "+this.nombre+" y voy a intentar montar un ramo.");
//        Ramo r = new Ramo();
//        if(r.verTotalPreparados() != 0){
//            this.cantidad_ramos++;
//            System.out.println("Había al menos una unidad de cada flor lista, así que monte un ramo.");
//        }else{
//            System.out.println("No hay las suficientes flores listas, no puedo montar un ramo.");
//        }
//        
//        System.out.println("He montado un total de "+this.cantidad_ramos+" ramos.");
//    }
    
    public Integer verRamos(){
        return this.cantidad_ramos;
    }
    
}
