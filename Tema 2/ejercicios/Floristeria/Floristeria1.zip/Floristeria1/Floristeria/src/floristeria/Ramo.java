package floristeria;

import java.util.HashMap;
import java.util.concurrent.Semaphore;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Ramo extends Thread{
    static Integer total = 1;
    public HashMap<String, Integer> ramo;
    Semaphore sem;

    public Ramo(Semaphore s) {
        ramo = new HashMap<String, Integer>() {
            {
                put("Rosa", 0);
                put("Lirio", 0);
                put("Clavel", 0);
            }
        };
        
        sem = s;
    }

    Ramo() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private void añadirRosa() {
        this.ramo.put("Rosa", this.ramo.get("Rosa") + 1);
    }

    private void añadirLirio() {
        this.ramo.put("Lirio", this.ramo.get("Lirio") + 1);
    }

    private void añadirClavel() {
        this.ramo.put("Clavel", this.ramo.get("Clavel") + 1);
    }
    
    public void añadirFlor(String nombre){
        if(this.ramo.containsKey(nombre)){
            this.ramo.put(nombre, this.ramo.get(nombre)+1);
            System.out.println("He preparado una flor -> "+nombre+" hay un total de "+this.ramo.get(nombre)+" flores de este tipo preparadas.");
        }else{
            throw new RuntimeException("No existe la flor");
        }
    }
    
//    public void montarRamo(){
//        
//        try {
//            System.out.println("Montando el ramo numero "+this.total);
//            
//            sem.acquire();
//            
//            this.añadirRosa();
//            this.añadirLirio();
//            this.añadirClavel();
//            this.total++;
//            
//        } catch (InterruptedException ex) {
//            Logger.getLogger(Ramo.class.getName()).log(Level.SEVERE, null, ex);
//            System.out.println("Fallo en semáforos al montar ramo.");
//        }
//        sem.release();
//
//    }
    
    public Integer verTotalPreparados(){
        System.out.println("Hay un total de "+this.total+" ramos preparados para montar.");
        return this.total;
    }
    
    
    public Integer verRosa(){
        return this.ramo.get("Rosa");
    }
    
    public Integer verLirio(){
        return this.ramo.get("Lirio");
    }
    
    public Integer verClavel(){
        return this.ramo.get("Clavel");
    }

}
