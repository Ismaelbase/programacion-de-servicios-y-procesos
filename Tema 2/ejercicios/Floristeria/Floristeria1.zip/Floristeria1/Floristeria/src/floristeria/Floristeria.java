package floristeria;

import java.util.Scanner;
import java.util.concurrent.Semaphore;

public class Floristeria {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        int cantidad = 0;

        Semaphore s = new Semaphore(1);
        // Nombres de las flores: Rosa - Lirio - Clavel
        Preparador p1 = new Preparador("Juan","Rosa", s);
        Preparador p2 = new Preparador("Paco","Lirio", s);
        Preparador p3 = new Preparador("Ana","Clavel", s);

        Montador m1 = new Montador("Carmen",2);

        System.out.println("¿Cuantos ramos quieres montar?");
        cantidad = input.nextInt();

        for (int i = 0; i < cantidad; i++) {
            p1.run();
            p2.run();
            p3.run();
        }

        for (int i = 0; i < cantidad; i++) {
            m1.run();
        }

    }

}
