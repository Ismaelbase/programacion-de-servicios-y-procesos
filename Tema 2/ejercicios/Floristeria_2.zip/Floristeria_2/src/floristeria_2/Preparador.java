
package floristeria_2;

import java.lang.reflect.Array;
import java.util.concurrent.Semaphore;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Preparador extends Thread{
    
    private final String[] nombre_flores = {"Lirio","Clavel","Rosa"};
    public int[] cantidad_flores = {0,0,0};
    
    String flor;
    String nombre;
    Semaphore sem;
    
    Preparador(String nom, Semaphore s, String f){
        this.nombre = nom;
        this.sem = s;
        this.flor = f;
    }

    Preparador() {
        
    }
    
    @Override
    public void run(){
        
        for(int i=0; i<nombre_flores.length;i++){
            if(nombre_flores[i].equalsIgnoreCase(this.flor)){
                try {
                    
                    this.sem.acquire();
                    
                    this.cantidad_flores[i]++;
                    System.out.println("Soy el trabajador "+this.nombre+" y he preparado un "+this.flor);
                    System.out.println("Hay un total de "+this.cantidad_flores[i]+" "+this.flor+" preparadas.");
                    
                } catch (InterruptedException ex) {
                    Logger.getLogger(Preparador.class.getName()).log(Level.SEVERE, null, ex);
                }
                
                this.sem.release();
            }
        }
        
    }
    
}
