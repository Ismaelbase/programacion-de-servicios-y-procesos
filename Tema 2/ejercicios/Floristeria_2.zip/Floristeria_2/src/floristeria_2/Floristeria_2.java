package floristeria_2;

import java.util.concurrent.Semaphore;

public class Floristeria_2 {
    public static void main(String[] args) {
        
        // Flores: Lirio - Clavel - Rosa
        // Preparadores: String nom, Semaphore s, String f
        // Montador: String nom, Semaphore s
        
        Semaphore s = new Semaphore(1);
        
        Preparador p1 = new Preparador("Ana",s,"Lirio");
        Preparador p2 = new Preparador("Juan",s,"Clavel");
        Preparador p3 = new Preparador("Raquel",s,"Rosa");
        Montador m1 = new Montador("Pedro",s, 3);
        
        p1.run();
        p2.run();
        p3.run();
        m1.run();
        
        
        
    }
    
}
