package floristeria_2;

import java.util.concurrent.Semaphore;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Montador extends Thread{
    String nombre;
    int total_montados;
    Semaphore sem;
    int montar;
    
    Montador(String nom, Semaphore s, int m){
        this.nombre = nom;
        this.sem = s;
        this.montar = m;
    }
    
    @Override
    public void run(){
        Preparador p = new Preparador();
        
        for(int i=0;i<this.montar;i++){
            
        
            while(p.cantidad_flores[0] == 0 || p.cantidad_flores[1] == 0 || p.cantidad_flores[2] == 0){
                try {
                    wait();
                    System.out.println("Soy el preparador "+this.nombre+", estoy esperando a que haya más flores.");
                } catch (InterruptedException ex) {
                    Logger.getLogger(Montador.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

            try {
                sem.acquire();
                this.total_montados++;

                System.out.println("Soy el trabajador "+this.nombre+" y he montado un ramo.");
                System.out.println("Ahora hay un total de "+total_montados+" ramos montados.");


            } catch (InterruptedException ex) {
                Logger.getLogger(Montador.class.getName()).log(Level.SEVERE, null, ex);
            }
            sem.release();
        
        }
                    
            
            
//
//        if(p.cantidad_flores[0] != 0 && p.cantidad_flores[1] != 0 && p.cantidad_flores[2] != 0){
//            
//            try {
//                sem.acquire();
//            } catch (InterruptedException ex) {
//                Logger.getLogger(Montador.class.getName()).log(Level.SEVERE, null, ex);
//            }
//            
//            this.total_montados++;
//            
//            System.out.println("Soy el trabajador "+this.nombre+" y he montado un ramo.");
//            System.out.println("Ahora hay un total de "+total_montados+" ramos montados.");
//            sem.release();
//            
//        }else{
//            
//        }
        
    }
    
}
