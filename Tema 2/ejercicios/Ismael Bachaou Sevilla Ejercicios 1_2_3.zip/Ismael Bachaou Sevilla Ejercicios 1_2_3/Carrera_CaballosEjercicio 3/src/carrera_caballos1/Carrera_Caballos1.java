package carrera_caballos1;

import java.util.Random;
import java.util.Scanner;
import java.util.concurrent.Semaphore;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Carrera_Caballos1 {

    public static int meta = 0;
    public static Random r = new Random();
    public static boolean carrera = true;

    public static class Caballo extends Thread {

        String nombre = "";
        Semaphore sem = new Semaphore(1);
        int posicion = 0;

        Caballo(String nom) {
            this.nombre = nom;
        }

        @Override
        public void run() {

            while (this.posicion < meta && carrera) {
                try {
                    sleep(1000);
                } catch (InterruptedException ex) {
                    
                }

                try {
                    this.sem.acquire();
                } catch (InterruptedException ex) {
                    Logger.getLogger(Carrera_Caballos1.class.getName()).log(Level.SEVERE, null, ex);
                }
                int tirada = r.nextInt(6) + 1;

                this.sem.release();

                this.posicion += tirada;

                System.out.println("Soy el caballo " + this.nombre + " he sacado un " + tirada + " voy por la casilla " + this.posicion);
            }

            if (carrera) {
                try {
                    this.sem.acquire();
                        carrera = false;
                        System.out.println("=====================");
                        System.out.println(this.nombre + " ha ganado la carrera!");
                        System.out.println("=====================");
                    this.sem.release();
                } catch (InterruptedException ex) {
                    Logger.getLogger(Carrera_Caballos1.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }
    public static void main(String[] args) {
        Random r = new Random();
        Scanner teclado = new Scanner(System.in);
        meta = 20;
        
        System.out.println("Dim cuantos caballos quieres que corran la carrera: ");
        int cantidad = teclado.nextInt();
        
        // Diez nombres de caballos, por si son 10 caballos o menos los que participan.
        String[] nombres_caballos = new String[]{"Sangre Segura","Galante",
                                    "Bucefalo","Pegaso","Rocinante","Sardinilla",
                                    "Merengo","Babieca","Sombra Gris","Perdigon"};
        
        Caballo[] caballos = new Caballo[cantidad];
        
        for(int i=0;i<cantidad;i++){
            if(cantidad<=10){
                caballos[i] = new Caballo(nombres_caballos[i]);
                caballos[i].start();
            }else{
                caballos[i] = new Caballo("Caballo ["+i+"]");
                caballos[i].start();
            }
        }
    }

}
