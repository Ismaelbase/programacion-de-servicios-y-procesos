package floristeria_4;

import java.util.concurrent.Semaphore;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Floristeria_4 {

    static String[] nombre_flor = {"Lirio", "Clavel", "Rosa"};
    static int[] mostrador = {0, 0, 0};
    static Semaphore[] array_semaforos = {new Semaphore(1), new Semaphore(1), new Semaphore(1)};
    static int total_ramos = 0;
    static int total_flores = 0;
    static boolean terminado = false;
    static Semaphore sem_preparador = new Semaphore(1);

    public static class Preparador extends Thread {

        
        String nombre;
        int id;

        Preparador(String nom, int identificador) {
            this.nombre = nom;
            this.id = identificador;
        }

        @Override
        public void run() {
            while (!terminado) {
                try {
                    if (mostrador[id] == 0) {
                        array_semaforos[id].acquire();
                        mostrador[id]++;
                        array_semaforos[id].release();

                        sem_preparador.acquire();
                        total_flores++;
                        System.out.println("He puesto un " + nombre_flor[id] + " con esta se han puesto un total de " + total_flores + " flores.");
                        sem_preparador.release();
                    } else {
                        sleep(500);
                    }

                } catch (InterruptedException ex) {
                    throw new RuntimeException("Error en semaforo de preparador.");
                }
            }

        }
    }

    public static class Montador extends Thread {

        int cantidad_ramos;
        String nombre;

        Montador(String nom, int cant) {
            this.nombre = nom;
            this.cantidad_ramos = cant;
        }

        @Override
        public void run() {
            try {
                sleep(500);
            } catch (InterruptedException ex) {
                Logger.getLogger(Floristeria_4.class.getName()).log(Level.SEVERE, null, ex);
            }
            int i = 0;

            while (i < this.cantidad_ramos) {
                System.out.println("Soy el montador " + this.nombre + " voy a intentar montar un ramo.");
                if (mostrador[0] == 1 && mostrador[1] == 1 && mostrador[2] == 1) {
                    try {
                        array_semaforos[0].acquire();
                        array_semaforos[1].acquire();
                        array_semaforos[2].acquire();

                        mostrador[0]--;
                        mostrador[1]--;
                        mostrador[2]--;
                        

                        array_semaforos[0].release();
                        array_semaforos[1].release();
                        array_semaforos[2].release();
                    } catch (InterruptedException ex) {
                        throw new RuntimeException("Error del montador en el array de semaforos.");
                    }
                    total_ramos++;
                    System.out.println("Ramo montado, ahora hay un total de " + total_ramos + " ramos montados.");
                    i++;
                } else {
                    try {
                        sleep(1000);
                        System.out.println("Aun no estan disponibles todas las flores, esperare.");
                    } catch (InterruptedException ex) {
                        throw new RuntimeException("Error al dormir al montador.");
                    }
                }

            }
            terminado = true;
        }

    }

    public static void main(String[] args) throws InterruptedException {
        // String nom, int identificador, Semaphore s

        Preparador p1 = new Preparador("Ana", 0);
        Preparador p2 = new Preparador("Julio", 1);
        Preparador p3 = new Preparador("Roberto", 2);

        // String nom, int cant, Semaphore s
        Montador m1 = new Montador("Carmen", 5);

        p1.start();
        p2.start();
        p3.start();
        m1.start();
    }

}
