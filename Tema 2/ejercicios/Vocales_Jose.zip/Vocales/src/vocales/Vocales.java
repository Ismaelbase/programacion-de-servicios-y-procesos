/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vocales;
import java.util.concurrent.Semaphore;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author EAG
 */
public class Vocales {
    static String cadena;
    static int cantidad;
    //static Semaphore sem;
    
    static class contador extends Thread{
        
        char v;
        contador(char vocal/*, Semaphore s*/){
            v=vocal;
            //sem = s;
        }
        
        public synchronized void run(){
            for (int i = 0; i < cadena.length(); i++) {
                if (cadena.charAt(i)==v) {
                    /*try {
                        sem.acquire();
                    } catch (InterruptedException ex) {
                        Logger.getLogger(Vocales.class.getName()).log(Level.SEVERE, null, ex);
                    }*/
                    cantidad++;
                    //sem.release();
                }
            }
        }
    }  
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       //Semaphore sem = new Semaphore(1);
        contador as = new contador('a'/*, sem*/); 
        contador es = new contador('e'/*, sem*/);
        contador is = new contador('i'/*, sem*/);
        contador os = new contador('o'/*, sem*/);
        contador us = new contador('u'/*, sem*/);
        
        cadena = "en un lugar de la mancha de cuyo nombre no quiero acordarme";
        
        as.start();
        es.start();
        is.start();
        os.start();
        us.start();
        
        System.out.println(cadena);
        System.out.println("VOCALES: " + cantidad);
        
    }
    
}
